#include <iostream>
#include <opencv2\opencv.hpp>

cv::Mat problem_a_rotate_forward(cv::Mat img, double angle) {
	cv::Mat output;
	//////////////////////////////////////////////////////////////////////////////
	//                         START OF YOUR CODE                               //
	//////////////////////////////////////////////////////////////////////////////
	angle = angle * (CV_PI / 180);

	double t1 = (double)img.rows / 2.0;
	double t2 = (double)img.cols / 2.0;

	double r1 = (-t1) * cos(angle) - (-t2) * sin(angle);
	double r2 = ((double)img.rows - t1) * cos(angle) - ((double)img.cols - t2) * sin(angle);
	double c1 = ((double)img.rows - t1) * sin(angle) + (-t2) * cos(angle);
	double c2 = (-t1) * sin(angle) + ((double)img.cols - t2) * cos(angle);

	double wr = r2 - r1;
	double wc = c2 - c1;

	output = cv::Mat::zeros(wr, wc, CV_8UC3);
	double rotx, roty;

	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			rotx = ((i - (double)img.rows / 2) * cos(angle) + (j - (double)img.cols / 2) * sin(angle));
			roty = ((-1) * (i - (double)img.rows / 2) * sin(angle) + (j - (double)img.cols / 2) * cos(angle));
			rotx += wr / 2;
			roty += wc / 2;

			if ((rotx <= 0) || (rotx >= output.rows) || (roty <= 0) || (roty >= output.cols)) {
				//output.at<cv::Vec3b>(rotx, roty) = cv::Vec3b(0, 0);
			}
			else {
				output.at<cv::Vec3b>(rotx, roty) = img.at<cv::Vec3b>(i, j);
			}
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////
	//                          END OF YOUR CODE                                //
	//////////////////////////////////////////////////////////////////////////////
	cv::imshow("a_output", output); cv::waitKey(0);
	return output;
}

cv::Mat problem_b_rotate_backward(cv::Mat img, double angle) {
	cv::Mat output;

	//////////////////////////////////////////////////////////////////////////////
	//                         START OF YOUR CODE                               //
	//////////////////////////////////////////////////////////////////////////////
	angle = angle * (CV_PI / 180);

	double t1 = (double)img.rows / 2.0;
	double t2 = (double)img.cols / 2.0;

	double r1 = (-t1) * cos(angle) - (-t2) * sin(angle);
	double r2 = ((double)img.rows - t1) * cos(angle) - ((double)img.cols - t2) * sin(angle);
	double c1 = ((double)img.rows - t1) * sin(angle) + (-t2) * cos(angle);
	double c2 = (-t1) * sin(angle) + ((double)img.cols - t2) * cos(angle);

	double wr = r2 - r1;
	double wc = c2 - c1;

	output = cv::Mat::zeros(wr, wc, CV_8UC3);
	double rotx, roty;

	for (int i = 0; i < output.rows; i++) {
		for (int j = 0; j < output.cols; j++) {
			rotx = (((double)i - wr / 2) * cos(angle) - ((double)j - wc / 2) * sin(angle));
			roty = (((double)i - wr / 2) * sin(angle) + ((double)j - wc / 2) * cos(angle));
			rotx += (double)img.rows / 2;
			roty += (double)img.cols / 2;

			if ((rotx <= 0) || (rotx >= img.rows) || (roty <= 0) || (roty >= img.cols)) {
				//output.at<cv::Vec3b>(rotx, roty) = cv::Vec3b(0, 0);
			}
			else {
				output.at<cv::Vec3b>(i, j) = img.at<cv::Vec3b>(rotx, roty);
			}
		}
	}
	//////////////////////////////////////////////////////////////////////////////
	//                          END OF YOUR CODE                                //
	//////////////////////////////////////////////////////////////////////////////

	cv::imshow("b_output", output); cv::waitKey(0);

	return output;
}

cv::Mat problem_c_rotate_backward_interarea(cv::Mat img, double angle) {
	cv::Mat output;

	//////////////////////////////////////////////////////////////////////////////
	//                         START OF YOUR CODE                               //
	//////////////////////////////////////////////////////////////////////////////
	angle = angle * (CV_PI / 180);

	double t1 = (double)img.rows / 2.0;
	double t2 = (double)img.cols / 2.0;

	double r1 = (-t1) * cos(angle) - (-t2) * sin(angle);
	double r2 = ((double)img.rows - t1) * cos(angle) - ((double)img.cols - t2) * sin(angle);
	double c1 = ((double)img.rows - t1) * sin(angle) + (-t2) * cos(angle);
	double c2 = (-t1) * sin(angle) + ((double)img.cols - t2) * cos(angle);

	double wr = r2 - r1;
	double wc = c2 - c1;

	output = cv::Mat::zeros(wr, wc, CV_8UC3);
	double rotx, roty;

	int a, b, c, d;
	double n, m, p, q;

	for (int i = 0; i < output.rows; i++) {
		for (int j = 0; j < output.cols; j++) {
			rotx = (((double)i - wr / 2) * cos(angle) - ((double)j - wc / 2) * sin(angle));
			roty = (((double)i - wr / 2) * sin(angle) + ((double)j - wc / 2) * cos(angle));
			rotx += (double)img.rows / 2;
			roty += (double)img.cols / 2;
			b = (int)rotx;
			a = (int)rotx; a++;
			d = (int)roty;
			c = (int)roty; c++;
			n = (double)c - roty;
			m = roty - (double)d;
			p = rotx - (double)b;
			q = (double)a - rotx;

			if ((rotx <= 0) || (rotx >= img.rows) || (roty <= 0) || (roty >= img.cols)) {
				//output.at<cv::Vec3b>(rotx, roty) = cv::Vec3b(0, 0);
			}
			else {
				if ((a >= img.rows) || (c >= img.cols)) {
					output.at<cv::Vec3b>(i, j) = img.at<cv::Vec3b>(rotx, roty);
				}
				else output.at<cv::Vec3b>(i, j) = q * m * img.at<cv::Vec3b>(b, c) + q * n * img.at<cv::Vec3b>(b, d) + p * n * img.at<cv::Vec3b>(a, d) + p * m * img.at<cv::Vec3b>(a, c);
			}
		}
	}
	//////////////////////////////////////////////////////////////////////////////
	//                          END OF YOUR CODE                                //
	//////////////////////////////////////////////////////////////////////////////

	cv::imshow("c_output", output); cv::waitKey(0);

	return output;
}

int main(void) {

	double angle = -15.0f;

	cv::Mat input = cv::imread("lena.jpg");
	//Fill problem_a_rotate_forward and show output
	problem_a_rotate_forward(input, angle);
	//Fill problem_b_rotate_backward and show output
	problem_b_rotate_backward(input, angle);
	//Fill problem_c_rotate_backward_interarea and show output
	problem_c_rotate_backward_interarea(input, angle);
}